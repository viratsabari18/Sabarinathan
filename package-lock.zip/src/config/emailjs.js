
export const emailjsConfig = {
  serviceId: 'service_v3d7z39', 
  templateId: 'template_v1fgj9y', 
  userId: 'KP3fHJ_hXK_eoORsM' 
};